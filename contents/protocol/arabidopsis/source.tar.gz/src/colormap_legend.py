import os
import sys
import time
from datetime import datetime
import math
from pathlib import Path
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import skimage as sk
from skimage import io as skio
from skimage import transform
from PIL import Image, ImageDraw, ImageFont, ImageTk
import tkinter as tk
from tkinter import filedialog, PhotoImage
import czifile
import multiprocessing as mp

from utils import *

date_time = datetime.now().strftime("%Y%m%d-%H%M%S")

img_list = list(Path("../img/Masashi").rglob("*.czi"))
img_list = [s for s in img_list if not "OUT_" in str(s)]
#img_list = list(Path("../img/YuChun/Rep01/20260305 cytGRX-roGFP2 22 vs 31 RGF1 DAT1").rglob("*.czi"))
#img_list = list(Path("../img/YuChun/Rep01/20260306 cytGRX-roGFP2 22 vs 31 RGF1 DAT2").rglob("*.czi"))
#img_list = list(Path("../img/YuChun/Rep02/20260310 cytGRX-roGFP2 22 vs 31 RGF1 DAT1").rglob("*.czi"))
#img_list = list(Path("../img/YuChun/Rep02/20260311 cytGRX-roGFP2 22 vs 31 RGF1 DAT2").rglob("*.czi"))
#img_list = list(Path("../img/YuChun/Rep03/20260317 cytGRX-roGFP2 22 vs 31 RGF1 DAT1").rglob("*.czi"))
#img_list = list(Path("../img/YuChun/Rep03/20260318 cytGRX-roGFP2 22 vs 31 RGF1 DAT2").rglob("*.czi"))
img = img_list[38]
dirname = os.path.dirname(img)
basename = os.path.basename(img)
output_dirname = os.path.join(os.path.dirname(dirname), f"OUT_{os.path.basename(dirname)}")
output_basename = os.path.join(f"OUT_{basename.replace(".czi", ".TIF")}")
#'''Root region extraction'''
E405, E488, PI = imread(img)
e405, e405_mask = root_region(E405)
e488, e488_mask = root_region(E488)
protein_exist_mask = np.bitwise_or(e405_mask, e488_mask)
e405 = percentile_filter(e405)
e488 = percentile_filter(e488)
#'''Reduced-Oxidized state'''
ro = ro_state(e405, e488) * protein_exist_mask
print(f"{output_basename}: Avg = {np.mean(ro[ro > 0])}, Min = {ro.min()}, Max = {ro.max()}")

plt.imshow(ro, cmap = "bwr", vmin = -1, vmax = 1)
plt.axis("off")
plt.colorbar()
plt.savefig("./colormap_legend.tiff", dpi = 660, format = "tiff")
plt.close()