import os
import sys
import time
from datetime import datetime
import math
from pathlib import Path
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import skimage as sk
from skimage import io as skio
from skimage import transform
from PIL import Image, ImageDraw, ImageFont, ImageTk
import tkinter as tk
from tkinter import filedialog, PhotoImage
import czifile
import multiprocessing as mp


def scale_min_max(arr, range = (0, 1)):
    arr = (arr - arr.min()) / (arr.max() - arr.min())
    arr = arr * (range[1] - range[0]) + range[0]
    return arr


def imread(img_path):
    img_type = Path(img_path).suffix.lower()
    if img_type == ".czi":
        img = czifile.imread(img_path)
        _, _, channel, _, width, height, _ = img.shape
        E405 = img[0, 0, 0, 0, :, :, 0]
        E488 = img[0, 0, 1, 0, :, :, 0]
        PI   = img[0, 0, 2, 0, :, :, 0]
        return E405, E488, PI


def imsave(arr, output_path: str = ".", format = "tiff"):
    dirname = os.path.dirname(output_path)
    basename = os.path.basename(output_path)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    Image.fromarray(arr).save(output_path, format = format)
    

def percentile_filter(arr, perc = (0, 99)):
    '''Discard saturated pixels'''
    arr = np.double(arr)
    x = arr[arr > 0]
    lower_thresh = np.percentile(x, perc[0])
    upper_thresh = np.percentile(x, perc[1])
    unique_val_ratio = len(np.unique(arr)) / len(arr)
    ret = arr 
    if unique_val_ratio > 0.3:
        ret[arr < lower_thresh] = 0
        ret[arr > upper_thresh] = 0
    return ret
    
    
def root_region(arr, kernel_size: int = 3, filter = True):
    arr = np.double(arr)
    raw_arr = arr
    '''Median filter + Otsu thresholding'''
    neighborhood = sk.morphology.disk(kernel_size)
    arr = (arr - arr.min()) / (arr.max() - arr.min()) * 255.0
    mask = np.uint8(arr)
    if filter is True:
        mask = sk.filters.rank.median(mask, neighborhood)
    threshold = sk.filters.threshold_otsu(mask)
    mask = mask > threshold
    arr = raw_arr * mask
    return arr, mask


def cell_structure(arr):
    arr = np.double(arr)
    cell = (arr - arr.min()) / (arr.max() - arr.min()) * 255.0
    cell = np.uint8(cell)
    thresh = sk.filters.threshold_otsu(cell)
    cell = np.double(cell * (cell > thresh))
    return cell


def ro_state(arr_405, arr_488):
    e405 = np.double(arr_405)
    e488 = np.double(arr_488)
    e488 = e488 * np.max(e405) / np.max(e488)
    e488 = np.nan_to_num(e488, nan=0)
    e405 = e405 ** 2
    e488 = e488 ** 2
    ro = (e405 - e488) / (e405 + e488)
    ro = np.nan_to_num(ro, nan = 0)
    return ro


def search_global_min_max(img_list: str):
    global_min = np.inf
    global_max = -np.inf
    for img in img_list:
        e405, e488, _ = imread(img)
        e405, e405_mask = root_region(e405, output_path = None)
        e488, e488_mask = root_region(e488, output_path = None)
        protein_exist = np.bitwise_or(e405_mask, e488_mask)
        ro_img = ro_state(e405, e488) * protein_exist
        ro_img = percentile_filter(ro_img)
        global_min = min(global_min, ro_img.min())
        global_max = max(global_max, ro_img.max())
    return global_min, global_max


def global_ro_min_max(img_list: str):
    global_min = np.inf
    global_max = -np.inf
    for img in img_list:
        dirname = os.path.dirname(img)
        basename = os.path.basename(img)
        output_dirname = os.path.join(os.path.dirname(dirname), f"OUT_{os.path.basename(dirname)}")
        output_basename = os.path.join(f"OUT_{basename.replace(".czi", ".tiff")}")
        ## Root region extraction =============================================
        E405, E488, PI = imread(img)
        e405, e405_mask = root_region(E405)
        e488, e488_mask = root_region(E488)
        protein_exist_mask = np.bitwise_or(e405_mask, e488_mask) / 255.0
        e405 = percentile_filter(e405)
        e488 = percentile_filter(e488)
        ## Reduced-Oxidized state ==============================================
        ro = ro_state(e405, e488) * protein_exist_mask
        ro_mask = np.double(ro != 0)
        ro = ro + 1.0
        ro = ro * ro_mask
        global_min = min(global_min, ro.min())
        global_max = max(global_max, ro.max())
    return global_min, global_max


def lut(arr, center = 0.0):
    '''Directly insert 3 arrays into the RGB channel'''
    arr = np.double(arr)
    r = np.zeros(arr.shape, dtype=np.double)
    g = arr * (arr > center)  # oxidized
    b = arr * (arr < center)  # reduced
    r = Image.fromarray(np.uint8(r))
    g = Image.fromarray(np.uint8(g))
    b = Image.fromarray(np.uint8(b))
    rgb = Image.merge("RGB", (r, g, b))
    return rgb


def export_gray_as_lut(arr, output_path, cmap = "bwr", range = (-1, 1)):
    dirname = os.path.dirname(output_path)
    basename = os.path.basename(output_path)
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    plt.imsave(
        fname = output_path, 
        arr = arr, 
        cmap = cmap, 
        vmin = range[0], 
        vmax = range[1],
        format = "tiff"
    )