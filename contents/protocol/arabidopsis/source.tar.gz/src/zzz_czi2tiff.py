import os
import sys
import time
from datetime import datetime
import math
from pathlib import Path
import numpy as np
import pandas as pd
import skimage as sk
from skimage import io as skio
from skimage import transform
from PIL import Image, ImageDraw, ImageFont, ImageTk
import tkinter as tk
from tkinter import filedialog, PhotoImage
import czifile
import multiprocessing as mp


def czi2rgb(img_path: str, output_path: str):
    dirname = os.path.dirname(img_path)
    basename = os.path.basename(img_path)
    czifile.czi2tif(img_path)

img_list = list(Path("../img/test_sample/rep2 cytGRX-roGFP2 22c31c 2DAT").rglob("*.czi"))
czifile.czi2tif(img_list[0], "./test.tif")