import os
import sys
import time
from datetime import datetime
import math
from pathlib import Path
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import skimage as sk
from skimage import io as skio
from skimage import transform
from PIL import Image, ImageDraw, ImageFont, ImageTk
import czifile
import aicspylibczi as aics
import xml.etree.ElementTree as ET

from utils import *

img_list = list(Path("../img/Masashi").rglob("*.czi"))
img_list = [s for s in img_list if not "OUT_" in str(s)]
img = img_list[0]

czi = aics.CziFile(img)
czi.get_dims_shape()
root = czi.meta
#for elem in root.iter():
#    if "Stage" in elem.tag or "Position" in elem.tag:
#        print(elem.tag, elem.text)

for elem in root.iter():
    if elem.text and any(k in elem.tag for k in ["X", "Y"]):
        print(elem.tag, elem.text)