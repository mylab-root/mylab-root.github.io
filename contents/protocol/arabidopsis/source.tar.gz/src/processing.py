import os
import sys
import time
from datetime import datetime
import math
from pathlib import Path
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import skimage as sk
from skimage import io as skio
from skimage import transform
from PIL import Image, ImageDraw, ImageFont, ImageTk
import tkinter as tk
from tkinter import filedialog, PhotoImage
import czifile
import multiprocessing as mp

from utils import *

date_time = datetime.now().strftime("%Y%m%d-%H%M%S")

img_list = list(Path("../img/Masashi").rglob("*.czi"))
img_list = [s for s in img_list if not "OUT_" in str(s)]
#img_list = list(Path("../img/YuChun/Rep01/20260305 cytGRX-roGFP2 22 vs 31 RGF1 DAT1").rglob("*.czi"))
#img_list = list(Path("../img/YuChun/Rep01/20260306 cytGRX-roGFP2 22 vs 31 RGF1 DAT2").rglob("*.czi"))
#img_list = list(Path("../img/YuChun/Rep02/20260310 cytGRX-roGFP2 22 vs 31 RGF1 DAT1").rglob("*.czi"))
#img_list = list(Path("../img/YuChun/Rep02/20260311 cytGRX-roGFP2 22 vs 31 RGF1 DAT2").rglob("*.czi"))
#img_list = list(Path("../img/YuChun/Rep03/20260317 cytGRX-roGFP2 22 vs 31 RGF1 DAT1").rglob("*.czi"))
img_list = list(Path("../img/YuChun/Rep03/20260318 cytGRX-roGFP2 22 vs 31 RGF1 DAT2").rglob("*.czi"))
for img in img_list:
    dirname = os.path.dirname(img)
    basename = os.path.basename(img)
    output_dirname = os.path.join(os.path.dirname(dirname), f"OUT_{os.path.basename(dirname)}")
    output_basename = os.path.join(f"OUT_{basename.replace(".czi", ".TIF")}")
    #'''Root region extraction'''
    E405, E488, PI = imread(img)
    imsave(E405, f"{output_dirname}/405 nm/{output_basename}")
    imsave(E488, f"{output_dirname}/488 nm/{output_basename}")
    PI_red = Image.merge(
        "RGB", 
        (
            Image.fromarray(np.uint8(scale_min_max(PI) * 255.0)), 
            Image.fromarray(np.zeros(PI.shape, dtype=np.uint8)),
            Image.fromarray(np.zeros(PI.shape, dtype = np.uint8))
        )
    )
    imsave(np.array(PI_red), f"{output_dirname}/PI/{output_basename}")
    e405, e405_mask = root_region(E405)
    e488, e488_mask = root_region(E488)
    protein_exist_mask = np.bitwise_or(e405_mask, e488_mask)
    e405 = percentile_filter(e405)
    e488 = percentile_filter(e488)
    #'''Reduced-Oxidized state'''
    ro = ro_state(e405, e488) * protein_exist_mask
    print(f"{output_basename}: Avg = {np.mean(ro[ro > 0])}, Min = {ro.min()}, Max = {ro.max()}")
    imsave(ro, f"{output_dirname}/RO/{output_basename}")
    export_gray_as_lut(ro, f"{output_dirname}/RO_LUT/{output_basename}")
    oxidized = ro * (ro > 0)
    reduced = ro * (ro < 0)
    export_gray_as_lut(oxidized, f"{output_dirname}/oxidized/{output_basename}")
    export_gray_as_lut(reduced, f"{output_dirname}/reduced/{output_basename}")
    #'''RGB image'''
    oxidized = (oxidized * 127.5 + 127.5) * (ro > 0)
    reduced = (reduced * 127.5 + 127.5) * (ro < 0)
    g = Image.fromarray(np.uint8(scale_min_max(cell_structure(PI)) * 255.0))
    r = Image.fromarray(np.uint8(oxidized))
    b = Image.fromarray(np.uint8(scale_min_max(reduced, (0, 127))))
    rgb = Image.merge("RGB", (r, g, b))
    imsave(np.array(rgb), f"{output_dirname}/RGB/{output_basename}")

print("Finished !!!")