import os
import sys
import time
from datetime import datetime
import math
from pathlib import Path
import numpy as np
import pandas as pd
import skimage as sk
from skimage import io as skio
from skimage import transform
from PIL import Image, ImageDraw, ImageFont, ImageTk
import tkinter as tk
from tkinter import filedialog, PhotoImage
import czifile
import multiprocessing as mp




img_list = list(Path("../img/test_sample").rglob("*.czi"))

img = czifile.imread(img_list[0])
#_, _, channel, _, width, height, _ = img.shape
E405 = img[0, 0, 0, 0, :, :, 0]
#E488 = img[0, 0, 1, 0, :, :, 0]
#PI   = img[0, 0, 2, 0, :, :, 0]

#Image.fromarray(E405).show()

neighborhood = sk.morphology.disk(5)
mask = sk.filters.rank.median(E405, neighborhood)
threshold = sk.filters.threshold_otsu(mask)
mask = mask > threshold

img = E405 * mask

Image.fromarray(img).show()
